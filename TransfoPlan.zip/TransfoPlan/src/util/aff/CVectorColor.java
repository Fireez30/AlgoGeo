package util.aff;

import java.awt.Color;
import java.util.ArrayList;

public class CVectorColor {

	public ArrayList<Color> couleurs;
	
	public CVectorColor(Color a, Color b, Color c) {
		couleurs = new ArrayList<Color>();
		couleurs.add(a);
		couleurs.add(b);
		couleurs.add(c);
	}
}
