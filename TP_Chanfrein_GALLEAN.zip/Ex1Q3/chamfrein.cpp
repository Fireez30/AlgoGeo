
#include <stdio.h>
#include <math.h>
#include <queue>
#include <iostream>
#include <time.h>
//#include "image_ppm.h"
#include "ImageBase.h"
#include "TRIPLE.h"
#include "Pixel.h"

using namespace std;
struct PixelComparator{

  bool operator()(const Pixel& p1, const Pixel& p2){
    return p1.value > p2.value;
  }

};

void initMask3(vector<vector<int> > &mask){
mask.push_back(vector<int>());
mask.push_back(vector<int>());  
mask.push_back(vector<int>());

  mask[0].push_back(1);
  mask[0].push_back(3);
  mask[0].push_back(1);

  mask[1].push_back(3);
  mask[1].push_back(0);
  mask[1].push_back(3);

  mask[2].push_back(1);
  mask[2].push_back(3);
  mask[2].push_back(1);


}

void initMask5(vector<vector<int> > &mask){
mask.push_back(vector<int>());
mask.push_back(vector<int>());  
mask.push_back(vector<int>());
mask.push_back(vector<int>());  
mask.push_back(vector<int>());

  mask[0].push_back(0);
  mask[0].push_back(9);
  mask[0].push_back(0);
  mask[0].push_back(9);
  mask[0].push_back(0);

  mask[1].push_back(9);
  mask[1].push_back(7);
  mask[1].push_back(5);
  mask[1].push_back(7);
  mask[1].push_back(9);

  mask[2].push_back(0);
  mask[2].push_back(5);
  mask[2].push_back(0);
  mask[2].push_back(5);
  mask[2].push_back(0);

  mask[3].push_back(9);
  mask[3].push_back(7);
  mask[3].push_back(5);
  mask[3].push_back(7);
  mask[3].push_back(9);

  mask[4].push_back(0);
  mask[4].push_back(9);
  mask[4].push_back(0);
  mask[4].push_back(9);
  mask[4].push_back(0);
}

int Random() {
  return (rand() % 250);
}

int main(int argc, char* argv[])
{
  char cNomImgEcrite[250];
  int hauteur,largeur,S,r;
  
  if (argc != 3){
    printf("Usage: ImageOut.pgm RayonImage\n"); 
    return -1;
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&r) ;


  srand(time(NULL));
  hauteur = r*2;
  largeur = r*2;
  
  ImageBase ImgOut(hauteur,largeur,false);
  ImageBase c(hauteur,largeur,true);

  priority_queue<Pixel, vector<Pixel>, PixelComparator> q;
  q.push(Pixel(r, r, 0));



  for (int i=0; i < hauteur; i++)
    for (int j=0; j < largeur; j++){
       ImgOut[i][j]=255;
    }

  //ImgOut[r][r] = 0;
  vector<vector<int> > mask = vector<vector<int> >();
  initMask3(mask);

  vector<vector<TRIPLE> > couleur;
  couleur.push_back(vector<TRIPLE>());
  couleur.push_back(vector<TRIPLE>());
  couleur.push_back(vector<TRIPLE>());

  couleur[0].push_back(TRIPLE(Random(),Random(),Random()));
  couleur[0].push_back(TRIPLE(Random(),Random(),Random()));
  couleur[0].push_back(TRIPLE(Random(),Random(),Random()));

  couleur[1].push_back(TRIPLE(Random(),Random(),Random()));
  couleur[1].push_back(TRIPLE(Random(),Random(),Random()));
  couleur[1].push_back(TRIPLE(Random(),Random(),Random()));

  couleur[2].push_back(TRIPLE(Random(),Random(),Random()));
  couleur[2].push_back(TRIPLE(Random(),Random(),Random()));
  couleur[2].push_back(TRIPLE(Random(),Random(),Random()));

  while(!q.empty()){
    Pixel p = q.top();
    q.pop();

    for(int i=0;i<mask.size();i++){
      for(int j=0;j<mask.size();j++){
        if(mask[i][j]>0){
          int VoisinX = p.getX() + (i-mask.size()/2);
          int VoisinY = p.getY() + (j-mask.size()/2);
          if(VoisinX >= 0 && VoisinX < largeur && VoisinY >= 0 && VoisinY < hauteur){
            if(p.getValue() + mask[i][j] <= r && ImgOut[VoisinX][VoisinY] > p.getValue() + mask[i][j]){
            c[VoisinX*3][VoisinY*3] = couleur[i][j].getX();
            c[VoisinX*3][VoisinY*3+1] = couleur[i][j].getY();
            c[VoisinX*3][VoisinY*3+2] = couleur[i][j].getZ();
            ImgOut[VoisinX][VoisinY] = p.getValue() + mask[i][j];
              q.push(Pixel(VoisinX,VoisinY, p.getValue() + mask[i][j]));
            }
          }
        }
      }
    }
  }

  for (int i=0; i < hauteur; i++)
    for (int j=0; j < largeur; j++){
       if(c[i*3][j*3]==255){
          c[i*3][j*3] = 0;
          c[i*3][j*3+1] = 0;
          c[i*3][j*3+2] = 0;
    }
  }

//ImgOut.save(cNomImgEcrite);
  c.save("couleur.ppm");

  mask.clear();
  return 1;
}
