#include "Pixel.h"

Pixel::Pixel(int x, int y, int v){
	this->x=x;
	this->y=y;
	this->value=v;
}
int Pixel::getX(){
	return this->x;
}
int Pixel::getY(){
	return this->y;
}
int Pixel::getValue(){
	return this->value;
}