
#include <stdio.h>
#include <math.h>
#include <queue>
#include <iostream>
#include "ImageBase.h"
#include "Pixel.h"

using namespace std;
struct PixelComparator{

  bool operator()(const Pixel& p1, const Pixel& p2){
    return p1.value > p2.value;
  }

};

vector<vector<int> > initMask3A(vector<vector<int> > &mask){
vector<vector<int> > maskA = vector<vector<int> >(mask);

  maskA[1][2]=0;

  maskA[2][0]=0;
  maskA[2][1]=0;
  maskA[2][2]=0;

  return maskA;
}

vector<vector<int> > initMask3P(vector<vector<int> > &mask){
vector<vector<int> > maskP = vector<vector<int> >(mask);
  maskP[0][0]=0;
  maskP[0][1]=0;
  maskP[0][2]=0;

  maskP[1][0]=0;


  return maskP;
  }

void initMask3(vector<vector<int> > &mask){
mask.push_back(vector<int>());
mask.push_back(vector<int>());  
mask.push_back(vector<int>());

  mask[0].push_back(0);
  mask[0].push_back(1);
  mask[0].push_back(0);

  mask[1].push_back(1);
  mask[1].push_back(0);
  mask[1].push_back(1);

  mask[2].push_back(0);
  mask[2].push_back(1);
  mask[2].push_back(0);


}

void displayMask(vector<vector<int> > mask){
  for (int i =0; i < mask.size(); i++){
    for (int j =0; j < mask[i].size();j++){
      cout << mask[i][j] << " ";
    }
    cout << "" << endl;
  }
}

void initMask5(vector<vector<int> > &mask){
mask.push_back(vector<int>());
mask.push_back(vector<int>());  
mask.push_back(vector<int>());
mask.push_back(vector<int>());  
mask.push_back(vector<int>());

  mask[0].push_back(0);
  mask[0].push_back(9);
  mask[0].push_back(0);
  mask[0].push_back(9);
  mask[0].push_back(0);

  mask[1].push_back(9);
  mask[1].push_back(7);
  mask[1].push_back(5);
  mask[1].push_back(7);
  mask[1].push_back(9);

  mask[2].push_back(0);
  mask[2].push_back(5);
  mask[2].push_back(0);
  mask[2].push_back(5);
  mask[2].push_back(0);

  mask[3].push_back(9);
  mask[3].push_back(7);
  mask[3].push_back(5);
  mask[3].push_back(7);
  mask[3].push_back(9);

  mask[4].push_back(0);
  mask[4].push_back(9);
  mask[4].push_back(0);
  mask[4].push_back(9);
  mask[4].push_back(0);
}

void TransformeeDistance(int argc,char** argv){

  char cNomImgLue[250];

  sscanf (argv[1],"%s",cNomImgLue) ;

  ImageBase ImgIn;
  ImgIn.load(cNomImgLue);
  ImageBase ImgOut(ImgIn.getWidth(), ImgIn.getHeight(), ImgIn.getColor());
  vector<vector<int> > mask = vector<vector<int> >();
  initMask3(mask);

    for (int i = 0; i < ImgIn.getWidth(); i++){
     for (int j = 0; j < ImgIn.getHeight(); j++){
      ImgOut[i][j] = ImgIn[i][j];
     }
   }

  vector<vector<int> > maskA = initMask3A(mask);
  vector<vector<int> > maskP = initMask3P(mask);

  displayMask(mask);
  displayMask(maskA);
  displayMask(maskP);

  for (int i = 1; i < ImgIn.getWidth() - 1; i++){
     for (int j = 1; j < ImgIn.getHeight() - 1; j++){
      
      if(ImgIn[i][j] != 255){
      for(int k=0;k<maskP.size();k++){
      for(int l=0;l<maskP.size();l++){

        if(maskP[k][l]>0){
          int VoisinX = i + (k-mask.size()/2);
          int VoisinY = j + (l-mask.size()/2);
          cout << (int) ImgIn[VoisinX][VoisinY] << endl;
          if(ImgIn[VoisinX][VoisinY] == 0){
            cout << "ah" << endl;
            if(ImgOut[VoisinX][VoisinY] > ImgOut[i][j] + maskP[k][l]){
              ImgOut[VoisinX][VoisinY] = ImgOut[i][j] + maskP[k][l];
            }
          }

        }//fin if masque>0
      }//fin for hauteur masque
    }//fin for largeur masque
  }//fin test pixel pas blanc
  }//fin hauteur image
}//fin largeur image
/*

  for (int i = ImgIn.getWidth() - 1; i > 0; i--){
    for (int j = ImgIn.getHeight() - 1; j > 0 ; j--){

    }
  }
  */

ImgOut.save("test.pgm");

}

int main(int argc, char* argv[])
{

    if (argc != 2){
    printf("Usage: ImageIn.pgm \n"); 
    return -1;
  }

TransformeeDistance(argc,argv);

  
 // int hauteur,largeur,S;
  
/* 
  priority_queue<Pixel, vector<Pixel>, PixelComparator> q;
  q.push(Pixel(r, r, 0));
/* */

/*
  for (int i=0; i < hauteur; i++)
    for (int j=0; j < largeur; j++){
       ImgOut[i][j]=255;
    }
*/
  //ImgOut[r][r] = 0;
  
/* 
  while(!q.empty()){
    Pixel p = q.top();
    q.pop();

    for(int i=0;i<mask.size();i++){
      for(int j=0;j<mask.size();j++){

        if(mask[i][j]>0){
          int VoisinX = p.getX() + (i-mask.size()/2);
          int VoisinY = p.getY() + (j-mask.size()/2);
          if(VoisinX >= 0 && VoisinX < largeur && VoisinY >= 0 && VoisinY < hauteur){
            if(p.getValue() + mask[i][j] <= r && ImgOut[VoisinX][VoisinY] > p.getValue() + mask[i][j]){
              ImgOut[VoisinX][VoisinY] = p.getValue() + mask[i][j];
              q.push(Pixel(VoisinX,VoisinY, p.getValue() + mask[i][j]));
            }
          }
        }
      }
    }
  }

/* */

  /* 
  for (int i=0; i < hauteur; i++)
    for (int j=0; j < largeur; j++){
       ImgOut[i][j] = (double)ImgOut[i][j]/(double)r * 255;
    }


  ImgOut.save(cNomImgEcrite);


  mask.clear();
  /* */
  return 0;
}
