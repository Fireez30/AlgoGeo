
#include <stdio.h>
#include <math.h>
#include <queue>
#include <iostream>
#include "ImageBase.h"
#include "Pixel.h"

using namespace std;

void Bresenham(int argc,char** argv,int x0,int x1,int y0,int y1){
  char cNomImgEcrite[250];
  int tailleImage;
  int epaisseur;
  
  if (argc != 4){
    printf("Usage: ImageOut.pgm RayonImage Epaisseur\n"); 
    exit(-1);
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&tailleImage) ;
  sscanf (argv[3],"%d",&epaisseur) ;

  ImageBase ImgOut(tailleImage,tailleImage, false);

  for(int i = 0; i < tailleImage; i++){
      for(int j = 0; j < tailleImage; j++)
        if (i == 0 || j == 0 ) ImgOut[i][j] = 255;
        else 
          ImgOut[i][j] == 0;
  }



  int dx = x1 - x0;
  int dy = y1 - y0;
  int x;
  int y = y0;

  int incrHor = 2*dy;
  int incrDiag = 2*(dx - dy);
  int e = 2*dy - dx;

  for (int x = x0; x <= x1; x++)
{

  for (int i=0; i < epaisseur; i++)
      ImgOut[x][y+i] = 255;

  if (e >= 0){
    y++;
    e = e - incrDiag;
  }
  else 
    e = e + incrHor;
} 

 ImgOut.save(cNomImgEcrite);

}


void Reveilles(int argc,char** argv,int x0,int x1,int y0,int y1){
  char cNomImgEcrite[250];
  int tailleImage;
   int epaisseur;
  
  if (argc != 4){
    printf("Usage: ImageOut.pgm RayonImage Epaisseur\n"); 
    exit(-1);
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&tailleImage) ;
  sscanf (argv[3],"%d",&epaisseur) ;

  ImageBase ImgOut(tailleImage,tailleImage, false);

  for(int i = 0; i < tailleImage; i++){
      for(int j = 0; j < tailleImage; j++)
        if (i == 0 || j == 0 ) ImgOut[i][j] = 255;
        else 
          ImgOut[i][j] == 0;
  }



  int vx = x1 - x0;
  int vy = y1 - y0;

  int u = vy*x0 - vx*y0;
  int r = vy*x0 - vx*y0 - u;
  
  int x = x0;
  int y = y0;


  while (x < x1)
{
  x++;
  r = r + vy;
  if (r < 0 || r >= vx){
    y++;
    r = r - vx;
  }

  for (int i=0; i < epaisseur; i++)
      ImgOut[x][y+i] = 255;

 ImgOut.save(cNomImgEcrite);

}}

int main(int argc, char** argv)
{


  int x0 = 0;
  int y0 = 0;

  int x1 = 70;
  int y1 = 15;

  string tmp;
  cout << "Algorithme ? r pour Reveilles , b pour Bresenham " << endl;
  cin >> tmp;
 
 if (tmp == "r") 
  Reveilles(argc,argv,x0,x1,y0,y1);
 else if (tmp == "b")
  Bresenham(argc,argv,x0,x1,y0,y1);
 else 
  {
    cout << "Mauvais choix d'Algorithme !" << endl;
  }
  return 0;
}
