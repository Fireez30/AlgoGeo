
#include <stdio.h>
#include <math.h>
#include <queue>
#include <iostream>

#include "image_ppm.h"
#include "Pixel.hpp"

using namespace std;
struct PixelComparator{

  bool operator()(const Pixel& p1, const Pixel& p2){
    return p1.value > p2.value;
  }

};

int main(int argc, char* argv[])
{
  char cNomImgEcrite[250];
  int hauteur, largeur, nTaille, S,rayon;
  
  if (argc != 3){
    printf("Usage: ImageOut.pgm rayon\n"); 
    exit (1) ;
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&rayon) ;
  OCTET *ImgOut;
  hauteur = rayon*2;
  largeur = rayon*2;
  nTaille = hauteur * largeur;
  
  priority_queue<Pixel, vector<Pixel>, PixelComparator> queue;
  queue.push(*new Pixel(rayon, rayon, 0));
  allocation_tableau(ImgOut, OCTET, nTaille);
  

  for (int i=0; i < hauteur; i++)
    for (int j=0; j < largeur; j++){
       ImgOut[i*largeur+j]=255;
    }

  ImgOut[rayon*largeur + rayon] = 0;
  int maskSize = 3;
  int** mask = new int*[maskSize];
  for(int i=0;i<maskSize;i++){
    mask[i]=new int[maskSize];
  }
  mask[0][0] = 1;
  mask[1][0] = 3;
  mask[2][0] = 1;
  mask[0][1] = 3;
  mask[2][1] = 3;
  mask[0][2] = 1;
  mask[1][2] = 3;
  mask[2][2] = 1;

  while(!queue.empty()){
    Pixel p = queue.top();
    queue.pop();

    for(int i=0;i<maskSize;i++){
      for(int j=0;j<maskSize;j++){
        if(mask[i][j]>0){
          int xPix = p.getX() + (i-maskSize/2);
          int yPix = p.getY() + (j-maskSize/2);
          if(xPix >= 0 && xPix < largeur && yPix >= 0 && yPix < hauteur){
            if(p.getValue() + mask[i][j] <= rayon && ImgOut[yPix*largeur + xPix] > p.getValue() + mask[i][j]){
              ImgOut[yPix*largeur + xPix] = p.getValue() + mask[i][j];
              queue.push(*new Pixel(xPix,yPix, p.getValue() + mask[i][j]));
            }
          }
        }
      }
    }
  }

  for (int i=0; i < hauteur; i++)
    for (int j=0; j < largeur; j++){
       if(ImgOut[i*largeur+j]==255) ImgOut[i*largeur+j] = 0;
       ImgOut[i*largeur+j] = (double)ImgOut[i*largeur+j]/(double)rayon * 255;
    }
  ecrire_image_pgm(cNomImgEcrite, ImgOut,  hauteur, largeur);
  free(ImgOut);
  free(mask);
  return 1;
}
