
#ifndef PIXEL_H_
#define PIXEL_H_

class Pixel{
	public:
		int x,y;
		int value;
		Pixel(int x,int y,int v);
		int getX();
		int getY();
		int getValue();

};

#endif 

