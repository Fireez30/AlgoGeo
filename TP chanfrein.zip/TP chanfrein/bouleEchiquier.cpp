// test_couleur.cpp : Seuille une image en niveau de gris

#include <stdio.h>
#include "image_ppm.h"
#include <math.h>
#include <algorithm>

using namespace std;
int main(int argc, char* argv[])
{
  char cNomImgEcrite[250];
  int nH, nW, nTaille, S,rayon;
  
  if (argc != 3){
    printf("Usage: ImageOut.pgm rayon\n"); 
    exit (1) ;
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&rayon) ;
  OCTET *ImgOut;
  nH = rayon*2;
  nW = rayon*2;
  nTaille = nH * nW;
  
  allocation_tableau(ImgOut, OCTET, nTaille);
   
  for (int i=0; i < nH; i++)
    for (int j=0; j < nW; j++){
      int distance = max(sqrt((rayon-i)*(rayon-i)),sqrt((rayon-j)*(rayon-j)));
      if(distance <= rayon)
       ImgOut[i*nW+j]=((double)distance/(double)rayon)*255;
    }
  ecrire_image_pgm(cNomImgEcrite, ImgOut,  nH, nW);
  free(ImgOut);
  return 1;
}
