// test_couleur.cpp : Seuille une image en niveau de gris

#include <stdio.h>
#include <math.h>
#include <queue>
#include <iostream>

#include "image_ppm.h"
#include "Pixel.hpp"

using namespace std;
struct GreaterValue{
  bool operator()(const Pixel& p1, const Pixel& p2){
    return p1.value > p2.value;
  }
};

int main(int argc, char* argv[])
{
  char cNomImgEcrite[250];
  int nH, nW, nTaille, S,rayon;
  
  if (argc != 3){
    printf("Usage: ImageOut.pgm rayon\n"); 
    exit (1) ;
  }
  sscanf (argv[1],"%s",cNomImgEcrite) ;
  sscanf (argv[2],"%d",&rayon) ;
  OCTET *ImgOut;
  nH = rayon*2;
  nW = rayon*2;
  nTaille = nH * nW;
  
  priority_queue<Pixel, vector<Pixel>, GreaterValue> queue;
  queue.push(*new Pixel(rayon, rayon, 0));
  allocation_tableau(ImgOut, OCTET, nTaille);
  

  for (int i=0; i < nH; i++)
    for (int j=0; j < nW; j++){
       ImgOut[i*nW+j]=255;
    }
  ImgOut[rayon*nW + rayon] = 0;
  int maskSize = 3;
  int** mask = new int*[maskSize];
  for(int i=0;i<maskSize;i++){
    mask[i]=new int[maskSize];
  }
  mask[0][0] = 1;
  mask[1][0] = 3;
  mask[2][0] = 1;
  mask[0][1] = 3;
  mask[2][1] = 3;
  mask[0][2] = 1;
  mask[1][2] = 3;
  mask[2][2] = 1;

  while(!queue.empty()){
    Pixel p = queue.top();
    queue.pop();

    for(int i=0;i<maskSize;i++){
      for(int j=0;j<maskSize;j++){
        if(mask[i][j]>0){
          int xPix = p.getX() + (i-maskSize/2);
          int yPix = p.getY() + (j-maskSize/2);
          if(xPix >= 0 && xPix < nW && yPix >= 0 && yPix < nH){
            if(p.getValue() + mask[i][j] <= rayon && ImgOut[yPix*nW + xPix] > p.getValue() + mask[i][j]){
              ImgOut[yPix*nW + xPix] = p.getValue() + mask[i][j];
              queue.push(*new Pixel(xPix,yPix, p.getValue() + mask[i][j]));
            }
          }
        }
      }
    }
  }

  for (int i=0; i < nH; i++)
    for (int j=0; j < nW; j++){
       if(ImgOut[i*nW+j]==255) ImgOut[i*nW+j] = 0;
       ImgOut[i*nW+j] = (double)ImgOut[i*nW+j]/(double)rayon * 255;
    }
  ecrire_image_pgm(cNomImgEcrite, ImgOut,  nH, nW);
  free(ImgOut);
  free(mask);
  return 1;
}
