#ifndef POINT
#define POINT

#endif // POINT

Class Point
{
    private :

}
