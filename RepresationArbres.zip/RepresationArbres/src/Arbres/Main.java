package Arbres;

import java.awt.BorderLayout;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;

public class Main {

	public static void main(String s[]) {
		ArrayList<Noeud> arbre = new ArrayList<Noeud>();
		Noeud origine = new Noeud(0,300,"Univers");
		Noeud a = new Noeud("Matiere");
		Noeud b = new Noeud("Anti-matiere");
		a.addFils(new Noeud("Hydrogene"));
		a.addFils(new Noeud("Helium"));
		b.addFils(new Noeud("Anti-Hydrogene"));
		b.addFils(new Noeud("Anti-Helium"));
		b.addFils(new Noeud("Anti-Oxygene"));
		
		origine.addFils(a);
		origine.addFils(b);
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
		int x = 100, y = 100, w = 800, h = 600;
		String fileName = "data/Trioker/trio-hypo-2.csv";
		JFrame frame = new JFrame("Repr�sentations d'arbres");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Vue v1;
		v1 = new Vue(w, h, fileName, false);
		v1.setBorder(BorderFactory.createLineBorder(Couleur.fg) );
		v1.setNoeuds(arbre);
		frame.add(v1);
		frame.pack();
		frame.setLocation(x, y);
		frame.setVisible(true);
			}});
	}
}
